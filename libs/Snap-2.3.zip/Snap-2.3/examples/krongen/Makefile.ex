#
#	configuration variables for the example

## Main application file
MAIN = krongen
DEPH = $(EXSNAPADV)/kronecker.h
DEPCPP = $(EXSNAPADV)/kronecker.cpp

